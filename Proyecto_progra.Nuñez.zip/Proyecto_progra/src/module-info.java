/**
 * 
 */
/**
 * 
 */
module Proyecto_progra {
	requires java.desktop;
	requires java.sql;
}